﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NPrintingTaskCall.App_Code
{
    public class DbRepository
    {

        /// <summary>
        /// Save task details in db
        /// </summary>
        /// <returns></returns>
        public static string SaveTaskDetail()
        {
            return "App.SaveEmailTaskDetail";

        }

        /// <summary>
        /// Get GetAttachmentDetails
        /// </summary>
        /// <returns></returns>
        public static string GetAttachmentDetails()
        {
            return "App.GetAttachmentDetails";
        }

        /// <summary>
        /// Get TaskExecution Details
        /// </summary>
        /// <returns></returns>
        public static string GetTaskExecutionDetails()
        {
            return "App.ExecuteNprintingTask";
        }

        /// <summary>
        /// Update Task Email Flag
        /// </summary>
        /// <returns></returns>
        public static string UpdateTaskEmailFlag()
        {
            return "App.UpdateTaskEmailFlag";
        }
        
        /// <summary>
        /// Update nextRunDate
        /// </summary>
        /// <returns></returns>
        public static string UpdateNextRunDate()
        {
            return "APP.UpdateNextRunDate";

        }
    }
}
